#include<stdio.h>
#include"LinkStack.h"
Box InitGame(LinkStack *Top);
LinkStack *FindAnswer(LinkStack *Top) ;

